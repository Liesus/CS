import java.util.Scanner;

/**
 * class InputOutput
 * 
 * Contains input/output methods provided by the IBO for primitive data types and Strings
 * 
 * @authors Kostas Dimitriou & Markos Hatzitaskos 
 * @version 1.0
 */
public abstract class InputOutput
{
	private static Scanner my_reader;
	
	public static void output(String string) {
	System.out.println(string);
	}

	public static char inputChar(String string) {
		output(string);
		if (InputOutput.my_reader == null) {
			my_reader = new Scanner(System.in);
			}	
		char wind = my_reader.next().charAt(0);
		return wind;
	}

	public static String input(String string) {
		output(string);
		if (InputOutput.my_reader == null) {
			my_reader = new Scanner(System.in);
			}
		String c = my_reader.next();
		String sun = my_reader.next();
		return sun;
	}

	public static int inputInt(String string) {
		output(string);
		if (InputOutput.my_reader == null) {
			my_reader = new Scanner(System.in);
			}
		String c = my_reader.next();
		int rain = Integer.parseInt(c);
		return rain;
	}

	public static String inputString(String string) {
		output(string);
		if (InputOutput.my_reader == null) {
			my_reader = new Scanner(System.in);
			}
		String c = my_reader.next();
		String snow = my_reader.next();
		return snow;
	}
}
